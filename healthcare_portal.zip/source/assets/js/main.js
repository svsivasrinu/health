$(document).ready(function(){
    $('.navigation_sidebar').perfectScrollbar();
    $(".btn_toggleclose").click(function(){
        toggleNav();
    });
    $(".btn_toggleopen").click(function(){
        toggleNav();
    });
    $(".hamburger").click(function(){
        toggleNav();
    });
}); 
 

function toggleNav(){
    $(".hamburger").toggle();
    $("#sidenav").toggleClass("sidebar_collaped");
    $("#mainwrapper").toggleClass("wrappercollapsed");
}
$(function () {
    $('.grid').click(function () {
        $("#grid1").addClass("active");
        $("#list1").removeClass("active");
        $('#list-card').hide();
        $('#grid-view').show();
    });
    $('.list').click(function () {
        $("#list1").addClass("active");
        $("#grid1").removeClass("active");

        $('#grid-view').hide();
        $('#list-card').show();
    });

});